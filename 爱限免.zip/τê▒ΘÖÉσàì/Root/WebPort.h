//
//  WebPort.h
//  爱限免
//
//  Created by apple on 16/7/6.
//  Copyright © 2016年 尚鑫. All rights reserved.
//

#ifndef WebPort_h
#define WebPort_h

//限免页面接口
#define LIMIT_URL(_page) [NSString stringWithFormat:@"http://iappfree.candou.com:8080/free/applications/limited?currency=rmb&page=%d",_page]

//降价页面接口
#define SALE_URL @"http://iappfree.candou.com:8080/free/applications/sales?currency=rmb&page=%d&category_id=%@"

//免费页面接口
#define FREE_URL @"http://iappfree.candou.com:8080/free/applications/free?currency=rmb&page=%d&category_id=%@"

//专题界面接口
#define TOPIC_URL @"http://1000phone.net:8088/app/iAppFree/api/topic.php?page=%d&number=20"

//热榜页面接口
#define HOT_URL @"http://1000phone.net:8088/app/iAppFree/api/hot.php?page=%d&number=10"


//分类界面接口
#define CATE_URL @"http://1000phone.net:8088/app/iAppFree/api/appcate.php"

//详情页面接口
// http://iappfree.candou.com:8080/free/applications/688743207?currency=rmb
#define DETAIL_URL @"http://iappfree.candou.com:8080/free/applications/455680974?currency=rmb"

//周边使用应用接口:
//http://iappfree.candou.com:8080/free/applications/recommend?longitude=116.344539&latitude=40.034346
//参数longitude,latitude填写经度和纬度。
#define NEARBY_APP_URL @"http://iappfree.candou.com:8080/free/applications/recommend?longitude=%lf&latitude=%lf"

#endif /* WebPort_h */
