//
//  General.h
//  爱限免
//
//  Created by apple on 16/7/6.
//  Copyright © 2016年 尚鑫. All rights reserved.
//

#ifndef General_h
#define General_h

/** 屏幕的宽 */
#define SCREEN_WIDTH [UIScreen mainScreen].bounds.size.width
/** 屏幕的高 */
#define SCREEN_HEIGHT [UIScreen mainScreen].bounds.size.height

/**
 *设置RGB
 */

#define SELECT_COLOR(_r,_g,_b,_alpha) [UIColor colorWithRed:_r/255.0 green:_g/255.0 blue:_b/255.0 alpha:_alpha]


/**
 *适配尺寸
 */

#define ADAPT_SIZE(_size) (_size/375.f) * SCREEN_WIDTH
#endif /* General_h */
