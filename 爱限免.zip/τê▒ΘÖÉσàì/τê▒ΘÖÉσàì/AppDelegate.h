//
//  AppDelegate.h
//  爱限免
//
//  Created by apple on 16/7/6.
//  Copyright © 2016年 尚鑫. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

