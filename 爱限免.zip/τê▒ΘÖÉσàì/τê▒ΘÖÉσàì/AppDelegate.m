//
//  AppDelegate.m
//  爱限免
//
//  Created by apple on 16/7/6.
//  Copyright © 2016年 尚鑫. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    return YES;
}

/**
 *  设置tabBar
 */
-(void)setRootViewController{
    
    self.window = [[UIWindow alloc]initWithFrame:[UIScreen mainScreen].bounds];
    [self.window makeKeyAndVisible];
    self.window.backgroundColor = [UIColor whiteColor];
    
    UITabBarController * tab =[[UITabBarController alloc]init];
    
    UINavigationController * nav_tf=[[UINavigationController alloc]initWithRootViewController:[[TimeFreeViewController alloc]init]];
    nav_tf.navigationBar.translucent = NO;
    nav_tf.tabBarItem = [[UITabBarItem alloc]initWithTitle:@"限免" image:[UIImage imageNamed:@"tabbar_limitfree"] selectedImage:[[UIImage imageNamed:@"tabbar_limitfree_press"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    
    
    
    UINavigationController * nav_cp=[[UINavigationController alloc]initWithRootViewController:[[CutPriceViewController alloc]init]];
    nav_cp.tabBarItem = [[UITabBarItem alloc]initWithTitle:@"降价" image:[UIImage imageNamed:@"tabbar_reduceprice"] selectedImage:[[UIImage imageNamed:@"tabbar_reduceprice_press"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    
    UINavigationController * nav_free=[[UINavigationController alloc]initWithRootViewController:[[FreeViewController alloc]init]];
    nav_free.tabBarItem = [[UITabBarItem alloc]initWithTitle:@"免费" image:[UIImage imageNamed:@"tabbar_appfree"] selectedImage:[[UIImage imageNamed:@"tabbar_appfree_press"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    
    UINavigationController * nav_proj=[[UINavigationController alloc]initWithRootViewController:[[ProjectViewController alloc]init]];
    nav_proj.tabBarItem = [[UITabBarItem alloc]initWithTitle:@"专题" image:[UIImage imageNamed:@"tabbar_subject"] selectedImage:[[UIImage imageNamed:@"tabbar_subject_press"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    
    UINavigationController * nav_hl=[[UINavigationController alloc]initWithRootViewController:[[HotlistViewController alloc]init]];
    nav_hl.tabBarItem = [[UITabBarItem alloc]initWithTitle:@"热榜" image:[UIImage imageNamed:@"tabbar_rank"] selectedImage:[[UIImage imageNamed:@"tabbar_rank_press"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    
    tab.viewControllers = @[nav_tf,nav_cp,nav_free,nav_proj,nav_hl];
    tab.tabBar.tintColor = [UIColor colorWithRed:0.96 green:0.16 blue:0.61 alpha:1.00];
    tab.tabBarItem.imageInsets=UIEdgeInsetsMake(6, 0,-6, 0);
    self.window.rootViewController = tab;
    
    
    
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
